#!/system/bin/sh
MODDIR=${0%/*}; MODDIR=${MODDIR%/*}
. "$MODDIR/config.conf" 2>/dev/null
TC=$(command -v tc); [ -z "$TC" ] && TC=/system/bin/tc
IF=$(cat "$MODDIR/.applied" 2>/dev/null)
case "${MODE:-normal}" in game) M=游戏模式;; aggressive) M=抢网模式;; *) M=正常模式;; esac
echo "╔══════════════ 模块状态面板 ══════════════╗"
echo "║  网络模式      : $M"
echo "║  热点限速      : ${ENABLE_TC:-?}"
echo "║  拥塞控制(CC)  : $(cat /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null)"
echo "║  RTO最小值     : $(cat /proc/sys/net/ipv4/tcp_rto_min 2>/dev/null) ms"
echo "╠══════════════════════════════════════════╣"
if [ -n "$IF" ] && [ -x "$TC" ]; then
  echo "║  热点限速接口  : $IF"
  $TC -s class show dev $IF | grep -E "class htb|Sent" | while read -r line; do echo "║    $line"; done
else
  echo "║  热点限速      : 未激活(热点未开或已关闭)"
fi
echo "╚══════════════════════════════════════════╝"
echo "日志: /data/local/tmp/netopt_bwctl.log"
