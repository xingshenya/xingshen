#!/system/bin/sh
ui_print " "
ui_print "  ╔═══════════════════════════════════╗"
ui_print "  ║   网络优化 · 热点限速 · 三模式     ║"
ui_print "  ║          by Kimi  v2.0            ║"
ui_print "  ╚═══════════════════════════════════╝"
ui_print " "
ui_print "  [音量+] 切换选项   [音量-] 确认选择"
ui_print " "

key_choice(){
  local out
  out=$(timeout 25 getevent -qlc 4 2>/dev/null | grep -m1 "KEY_VOLUME")
  case "$out" in
    *VOLUMEUP*DOWN*) echo up ;;
    *VOLUMEDOWN*DOWN*) echo down ;;
    *) echo none ;;
  esac
}

menu(){
  local title=$1; shift
  local n=$# sel=1 i k o
  ui_print "▶ $title"
  while :; do
    i=1
    for o in "$@"; do
      if [ $i -eq $sel ]; then ui_print "    [√] $o"; else ui_print "    [  ] $o"; fi
      i=$((i+1))
    done
    k=$(key_choice)
    case "$k" in
      up)   sel=$((sel-1)); [ $sel -lt 1 ] && sel=$n ;;
      down) ui_print " "; echo $sel; return ;;
      none) ui_print "    (无按键输入, 采用当前高亮项)"; echo $sel; return ;;
    esac
  done
}

c1=$(menu "选择【网络模式】" \
      "正常模式 - 基础优化, 省电友好" \
      "游戏模式 - 低延迟优先, 消灭ping突刺" \
      "抢网模式 - 吞吐优先, 拥挤WiFi抢网速")
ui_print " "

c2=$(menu "是否开启【热点设备限速】?" \
      "开启 - 按config.conf中的IP表限速" \
      "关闭 - 跳过限速功能")
ui_print " "

CFG=config.conf
case "$c1" in
  1) sed -i 's/^MODE=.*/MODE=normal/' $CFG ;;
  2) sed -i 's/^MODE=.*/MODE=game/' $CFG ;;
  3) sed -i 's/^MODE=.*/MODE=aggressive/' $CFG ;;
esac
[ "$c2" = "1" ] && sed -i 's/^ENABLE_TC=.*/ENABLE_TC=1/' $CFG || sed -i 's/^ENABLE_TC=.*/ENABLE_TC=0/' $CFG

ui_print " "
ui_print "  ╔═════════ 安装配置摘要 ═════════╗"
case "$c1" in
  1) ui_print "  ║  网络模式      : 正常模式      ║" ;;
  2) ui_print "  ║  网络模式      : 游戏模式      ║" ;;
  3) ui_print "  ║  网络模式      : 抢网模式      ║" ;;
esac
if [ "$c2" = "1" ]; then ui_print "  ║  热点限速      : 开启          ║"; else ui_print "  ║  热点限速      : 关闭          ║"; fi
ui_print "  ╚════════════════════════════════╝"
ui_print " "
ui_print "  ✓ 已启用 卸载完全恢复 功能"
ui_print "    首次启动自动备份原始网络参数"
ui_print "    面具卸载后自动恢复刷入前状态"
ui_print " "
ui_print "  网页控制台: 面具模块列表点本模块"
ui_print " "
