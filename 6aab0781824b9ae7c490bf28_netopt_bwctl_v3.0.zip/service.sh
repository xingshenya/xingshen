#!/system/bin/sh
MODDIR=${0%/*}
CONF="$MODDIR/config.conf"
LOG=/data/local/tmp/netopt_bwctl.log
BACKUP="$MODDIR/.backup"
. "$CONF"

log(){ echo "[$(date '+%m-%d %H:%M:%S')] $1" >> $LOG; }

# ---------- 备份原始值（仅首次运行执行） ----------
backup_original(){
  [ -f "$BACKUP" ] && return 0
  log "首次运行，备份原始网络参数..."
  : > "$BACKUP"

  # sysctl 参数
  for p in \
    net.ipv4.tcp_congestion_control \
    net.ipv4.tcp_fastopen \
    net.ipv4.tcp_mtu_probing \
    net.core.netdev_max_backlog \
    net.core.rmem_max \
    net.core.wmem_max \
    net.ipv4.tcp_rmem \
    net.ipv4.tcp_wmem \
    net.ipv4.tcp_rto_min \
    net.ipv4.tcp_slow_start_after_idle \
    net.ipv4.tcp_notsent_lowat \
    net.ipv4.tcp_no_metrics_save \
    net.ipv4.tcp_early_retrans
  do
    val=$(cat /proc/sys/${p} 2>/dev/null)
    [ -n "$val" ] && echo "SYSCTL|$p|$val" >> "$BACKUP"
  done

  # settings 数据库
  for s in wifi_sleep_policy captive_portal_mode network_avoid_bad_wifi; do
    val=$(settings get global $s 2>/dev/null)
    [ "$val" != "null" ] && [ -n "$val" ] && echo "SETTINGS|$s|$val" >> "$BACKUP"
  done

  # 网卡 txqueuelen 和 power_save
  IW=$(command -v iw)
  for w in wlan0 wlan1; do
    ip link show $w 2>/dev/null | grep -q "state UP" || continue
    txq=$(cat /sys/class/net/$w/tx_queue_len 2>/dev/null)
    [ -n "$txq" ] && echo "TXQ|$w|$txq" >> "$BACKUP"
    if [ -n "$IW" ]; then
      ps=$($IW dev $w get power_save 2>/dev/null | grep -oP "Power save: \K(on|off)")
      [ -n "$ps" ] && echo "PS|$w|$ps" >> "$BACKUP"
    fi
  done

  # 记录默认 qdisc 类型
  TC=$(command -v tc); [ -z "$TC" ] && TC=/system/bin/tc
  if [ -x "$TC" ]; then
    for w in wlan0 wlan1; do
      ip link show $w 2>/dev/null | grep -q "state UP" || continue
      qdisc=$($TC qdisc show dev $w 2>/dev/null | head -1 | awk '{print $2,$3,$4,$5}')
      [ -n "$qdisc" ] && echo "QDISC|$w|$qdisc" >> "$BACKUP"
    done
  fi

  log "备份完成，保存在 $BACKUP"
}

# ---------- 基础网络栈优化(所有模式共用) ----------
apply_sysctl(){
  CC=$(cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null)
  case "$CC" in *bbr*) TARGET=bbr;; *) TARGET=cubic;; esac
  echo $TARGET > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
  echo 3    > /proc/sys/net/ipv4/tcp_fastopen 2>/dev/null
  echo 1    > /proc/sys/net/ipv4/tcp_mtu_probing 2>/dev/null
  echo 8192 > /proc/sys/net/core/netdev_max_backlog 2>/dev/null
  echo 33554432 > /proc/sys/net/core/rmem_max 2>/dev/null
  echo 33554432 > /proc/sys/net/core/wmem_max 2>/dev/null
  echo "4096 131072 33554432" > /proc/sys/net/ipv4/tcp_rmem 2>/dev/null
  echo "4096 131072 33554432" > /proc/sys/net/ipv4/tcp_wmem 2>/dev/null
  log "基础优化已应用, cc=$TARGET"
}

# ---------- 模式配置: normal / game / aggressive ----------
apply_profile(){
  case "${MODE:-normal}" in
    game)       SLEEPPOL=2; RTO=100; SSAI=0; LOWAT=16384;    TXQ=1000; PS=off; NMS=1 ;;
    aggressive) SLEEPPOL=2; RTO=50;  SSAI=0; LOWAT=131072;   TXQ=3000; PS=off; NMS=1 ;;
    *)          SLEEPPOL=0; RTO=200; SSAI=1; LOWAT=4294967295; TXQ=1000; PS=on;  NMS=0 ;;
  esac
  # TCP 参数
  echo $RTO   > /proc/sys/net/ipv4/tcp_rto_min 2>/dev/null
  echo $SSAI  > /proc/sys/net/ipv4/tcp_slow_start_after_idle 2>/dev/null
  echo $LOWAT > /proc/sys/net/ipv4/tcp_notsent_lowat 2>/dev/null
  echo $NMS   > /proc/sys/net/ipv4/tcp_no_metrics_save 2>/dev/null
  echo 1      > /proc/sys/net/ipv4/tcp_early_retrans 2>/dev/null
  # 系统设置
  settings put global wifi_sleep_policy $SLEEPPOL 2>/dev/null
  settings put global captive_portal_mode 0 2>/dev/null
  settings put global network_avoid_bad_wifi 0 2>/dev/null
  # 网卡
  IW=$(command -v iw)
  for w in wlan0 wlan1; do
    ip link show $w 2>/dev/null | grep -q "state UP" || continue
    ip link set dev $w txqueuelen $TXQ 2>/dev/null
    [ -n "$IW" ] && $IW dev $w set power_save $PS 2>/dev/null
  done
  log "模式已应用: ${MODE:-normal} (rto=$RTO txq=$TXQ ps=$PS)"
}

# ---------- 本机 wlan fq 队列 ----------
apply_fq(){
  TC=$(command -v tc); [ -z "$TC" ] && TC=/system/bin/tc
  [ -x "$TC" ] || return
  for w in wlan0 wlan1; do
    ip link show $w 2>/dev/null | grep -q "state UP" || continue
    $TC qdisc replace dev $w root fq 2>/dev/null
  done
}

# ---------- 热点接口探测 ----------
find_iface(){
  if [ "$AP_IFACE" != "auto" ]; then
    ip link show "$AP_IFACE" 2>/dev/null | grep -q "state UP" && { echo "$AP_IFACE"; return; }
    return
  fi
  for c in ap0 swlan0 wlan1 wlan0; do
    ip link show "$c" 2>/dev/null | grep -q "state UP" && { echo "$c"; return; }
  done
}

# ---------- tc HTB 热点限速 ----------
apply_tc(){
  IFACE=$1
  TC=$(command -v tc); [ -z "$TC" ] && TC=/system/bin/tc
  [ -x "$TC" ] || { log "错误: 未找到 tc"; return 1; }
  $TC qdisc del dev $IFACE root 2>/dev/null
  $TC qdisc add dev $IFACE root handle 1: htb default 999 || return 1
  $TC class add dev $IFACE parent 1: classid 1:1 htb rate $TOTAL_RATE
  $TC class add dev $IFACE parent 1:1 classid 1:999 htb rate $DEFAULT_RATE ceil $TOTAL_RATE
  ID=10
  echo "$LIMITS" | tr ';' '\n' | while read ip rate ceil; do
    [ -z "$ip" ] && continue
    CEIL=${ceil:-$rate}
    $TC class add dev $IFACE parent 1:1 classid 1:$ID htb rate $rate ceil $CEIL
    $TC filter add dev $IFACE protocol ip parent 1:0 prio 1 u32 match ip dst $ip flowid 1:$ID
    log "限速: $ip -> $rate (ceil $CEIL)"
    ID=$((ID+1))
  done
  echo "$IFACE" > "$MODDIR/.applied"
  log "tc 已应用到 $IFACE"
}

# ---------- 主流程 ----------
log "service 启动, MODE=${MODE:-normal}"
backup_original
apply_sysctl
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 5; done
sleep 10

while true; do
  IF=$(find_iface)
  if [ "$ENABLE_TC" = "1" ] && [ -n "$IF" ] && [ "$(cat $MODDIR/.applied 2>/dev/null)" != "$IF" ]; then
    apply_tc "$IF"
  fi
  if { [ -z "$IF" ] || [ "$ENABLE_TC" != "1" ]; } && [ -f "$MODDIR/.applied" ]; then
    rm -f "$MODDIR/.applied"
  fi
  # WiFi 重连后参数会丢，定期补套
  apply_fq
  apply_profile
  sleep 10
done
