#!/system/bin/sh
MODDIR=${0%/*}
BACKUP="$MODDIR/.backup"
LOG=/data/local/tmp/netopt_bwctl_uninstall.log

log(){ echo "[$(date '+%m-%d %H:%M:%S')] $1" >> $LOG; }

log "开始卸载恢复流程"

# ---------- 清理 tc 限速规则 ----------
TC=$(command -v tc); [ -z "$TC" ] && TC=/system/bin/tc
IF=$(cat "$MODDIR/.applied" 2>/dev/null)
if [ -n "$IF" ] && [ -x "$TC" ]; then
  $TC qdisc del dev $IF root 2>/dev/null
  log "已清理热点接口 $IF 的 tc 规则"
fi

# ---------- 从备份恢复 ----------
if [ -f "$BACKUP" ]; then
  log "找到备份文件，开始恢复原始参数..."

  while IFS='|' read -r type key val; do
    [ -z "$type" ] && continue
    case "$type" in
      SYSCTL)
        # 恢复 sysctl 参数
        path="/proc/sys/$(echo $key | tr '.' '/')"
        if [ -w "$path" ]; then
          echo "$val" > "$path" 2>/dev/null
          log "恢复 sysctl: $key = $val"
        else
          log "跳过(不可写): $key"
        fi
        ;;
      SETTINGS)
        # 恢复 settings 数据库
        settings put global "$key" "$val" 2>/dev/null
        log "恢复 settings: $key = $val"
        ;;
      TXQ)
        # 恢复网卡 txqueuelen
        ip link set dev "$key" txqueuelen "$val" 2>/dev/null
        log "恢复 txqueuelen: $key = $val"
        ;;
      PS)
        # 恢复 WiFi 省电模式
        IW=$(command -v iw)
        if [ -n "$IW" ]; then
          $IW dev "$key" set power_save "$val" 2>/dev/null
          log "恢复 power_save: $key = $val"
        fi
        ;;
      QDISC)
        # 恢复 qdisc（先尝试还原原始类型，失败则删 root 让系统重建）
        if [ -x "$TC" ]; then
          # 先删除当前 qdisc
          $TC qdisc del dev "$key" root 2>/dev/null
          # val 格式如 "pfifo_fast 0:" 或 "fq 0:" 等，尝试重新添加
          qtype=$(echo "$val" | awk '{print $1}')
          if [ -n "$qtype" ]; then
            $TC qdisc add dev "$key" root $qtype 2>/dev/null
            log "恢复 qdisc: $key = $qtype"
          fi
        fi
        ;;
    esac
  done < "$BACKUP"

  log "备份恢复完成"
else
  log "警告: 未找到备份文件 (.backup)，跳过参数恢复"
  log "这通常是因为模块安装后从未启动过（service.sh 未运行）"
fi

# ---------- 清理日志和临时文件 ----------
rm -f /data/local/tmp/netopt_bwctl.log
rm -f "$MODDIR/.applied"
rm -f "$BACKUP"

log "卸载完成，已恢复到刷入前状态"
